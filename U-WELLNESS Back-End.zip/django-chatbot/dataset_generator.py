import json
import os
import concurrent.futures
from openai import OpenAI

# Use an environment variable for the API key
api_key = ""

# Read and process the paragraph about gym training
# Paragraph about gym training
gym_training_paragraph = """
Maintaining a healthy lifestyle involves a balance of regular physical activity, proper nutrition, and good mental health practices. Regular exercise, such as cardio and strength training, helps to improve cardiovascular health, build strength, and maintain a healthy weight. Additionally, physical activity releases endorphins, which can boost mood and reduce feelings of stress and anxiety. Alongside exercise, nutrition plays a crucial role in overall health. Consuming a balanced diet rich in fruits, vegetables, whole grains, lean proteins, and healthy fats provides essential nutrients and energy to fuel the body and support optimal function. Proper hydration is also key, as water helps regulate body temperature, transport nutrients, and flush out toxins. Finally, prioritizing mental health is essential for overall well-being. Practices such as mindfulness, meditation, and stress management techniques can help reduce anxiety, improve sleep quality, and enhance overall mental resilience.
"""

# Instantiate the OpenAI client
client = OpenAI(api_key=api_key)


# Function to generate assistant messages using ChatGPT API
def generate_assistant_messages(user_messages):
    try:
        completions = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": msg} for msg in user_messages],
            max_tokens=100,
            temperature=0.7,
        )
        return [
            completion.choices[0].message.content.strip() for completion in completions
        ]
    except Exception as e:
        print("Error:", e)
        return ["I'm sorry, I couldn't generate a response at the moment."] * len(
            user_messages
        )


# File path
file_path = "training.jsonl"

# Check if the file exists and set the mode accordingly
mode = "a" if os.path.exists(file_path) else "w"


paragraph_sentences = [
    sentence.strip()
    for sentence in gym_training_paragraph.strip().split(".")
    if sentence
]

# Batch processing
with concurrent.futures.ThreadPoolExecutor() as executor:
    # Generate questions and answers in batches
    user_messages = [sentence + "?" for sentence in paragraph_sentences]
    answers = generate_assistant_messages(user_messages)

# Write to the file in one go
with open(file_path, mode) as file:
    for sentence, answer in zip(paragraph_sentences, answers):
        dialogue = {
            "system": "Marv is a factual chatbot that is also sarcastic.",
            "user": sentence + "?",
            "assistant": answer,
        }
        file.write(json.dumps(dialogue) + "\n")

print("Data has been written or appended to the file 'training.jsonl'.")
