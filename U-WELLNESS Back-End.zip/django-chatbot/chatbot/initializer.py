import os
from dotenv import load_dotenv

load_dotenv()

from .gpt_lanchain import (
    get_pdf_files_from_folder,
    get_pdf_text,
    get_text_chunks,
    get_vectorstore,
    get_conversation_chain,
)

# # This will hold the initialized conversation chain
# conversation_chain = None

vectorstore = None


# def initialize():
#     # global conversation_chain
#     global vectorstore
#     folder_path = os.getenv("PDF_FOLDER_PATH")
#     pdf_files = get_pdf_files_from_folder(folder_path)
#     text = get_pdf_text(pdf_files)
#     text_chunks = get_text_chunks(text)
#     vectorstore = get_vectorstore(text_chunks)


def initialize():
    # global conversation_chain
    global vectorstore
    try:
        folder_path = os.getenv("PDF_FOLDER_PATH")
        if folder_path is None:
            raise FileNotFoundError("PDF folder path environment variable is not set.")

        pdf_files = get_pdf_files_from_folder(folder_path)
        if not pdf_files:
            raise FileNotFoundError("No PDF files found in the specified folder.")

        text = get_pdf_text(pdf_files)
        if not text:
            raise ValueError("Failed to extract text from PDF files.")

        text_chunks = get_text_chunks(text)
        if not text_chunks:
            raise ValueError("Failed to chunk the extracted text.")

        vectorstore = get_vectorstore(text_chunks)
        if vectorstore is None:
            raise ValueError("Failed to create vector store from text chunks.")

        # conversation_chain = get_conversation_chain(vectorstore)

    except Exception as e:
        raise RuntimeError(f"An error occurred during initialization: {e}")
