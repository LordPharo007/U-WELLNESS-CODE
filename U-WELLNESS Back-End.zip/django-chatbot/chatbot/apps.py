from django.apps import AppConfig


class ChatbotConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "chatbot"

    def ready(self):
        from .initializer import initialize

        # initialize()
        try:
            initialize()
        except RuntimeError as e:
            print(f"Initialization Error: {e}")
        except Exception as e:
            print(f"Unexpected Error: {e}")
