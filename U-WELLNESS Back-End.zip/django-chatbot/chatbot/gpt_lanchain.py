import os
import re
import random
import string
from dotenv import load_dotenv
import pdfplumber
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain.memory import ConversationBufferMemory
from langchain.chains import ConversationalRetrievalChain

load_dotenv()  # Load environment variables


def get_pdf_text(pdf_files):
    """Extracts and concatenates text from a list of PDF files using pdfplumber for better accuracy."""
    text = ""
    for pdf_file in pdf_files:
        try:
            with pdfplumber.open(pdf_file) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
        except Exception as e:
            print(f"Error processing {pdf_file}: {e}")
    return text


def get_text_chunks(text, chunk_size=500, overlap=100):
    """Splits the entire text into manageable chunks based on regex patterns."""
    sentences = re.split(
        r"\.\s+", text
    )  # Split text into sentences at each period followed by a space
    chunks = []
    current_chunk = ""

    for sentence in sentences:
        if len(current_chunk) + len(sentence) < chunk_size:
            current_chunk += sentence + ". "
        else:
            chunks.append(current_chunk)
            current_chunk = sentence + ". "

    if current_chunk:
        chunks.append(current_chunk)

    # Implementing overlap
    if overlap > 0 and len(chunks) > 1:
        overlapped_chunks = [chunks[0]]
        for i in range(1, len(chunks)):
            # Append overlap from the previous chunk to the current chunk
            overlap_text = chunks[i - 1][-overlap:]
            overlapped_chunks.append(overlap_text + chunks[i])
        return overlapped_chunks
    return chunks


def get_vectorstore(text_chunks):
    """Creates a vector store from text chunks using embeddings."""
    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.from_texts(texts=text_chunks, embedding=embeddings)
    return vectorstore


def get_conversation_chain(vectorstore):
    """Configures and returns a conversational retrieval chain."""
    llm = ChatOpenAI(
        api_key=os.getenv("OPENAI_API_KEY"), model="gpt-3.5-turbo-1106", temperature=0.3
    )
    memory = ConversationBufferMemory(memory_key="chat_history", return_messages=True)
    return ConversationalRetrievalChain.from_llm(
        llm=llm, retriever=vectorstore.as_retriever(k=5), memory=memory
    )


def get_pdf_files_from_folder(folder_path):
    """Retrieves a list of PDF file paths from the specified folder."""
    return [
        os.path.join(folder_path, f)
        for f in os.listdir(folder_path)
        if f.endswith(".pdf")
    ]


def is_simple_acknowledgment(user_input):
    """Determines if the user's input is a simple acknowledgment that does not require a detailed response."""

    user_input = user_input.lower().strip()
    # Remove punctuation from the user input
    user_input = user_input.translate(str.maketrans("", "", string.punctuation))
    simple_acknowledgments = [
        "ok",
        "okay",
        "k",
        "kk",
        "fine",
        "thanks",
        "thank you",
        "thx",
        "thanks a lot",
        "thank you very much",
        "got it",
        "understood",
        "alright",
        "cool",
        "great",
        "sure",
        "yes",
        "no problem",
        "np",
        "cheers",
        "awesome",
        "good",
        "perfect",
        "excellent",
        "wonderful",
        "nice",
        "sounds good",
        "lovely",
        "fantastic",
        "terrific",
        "yup",
        "yea",
        "yeah",
    ]
    return user_input in simple_acknowledgments


def generate_simple_response():
    """Generates a human-like simple response."""
    varied_acknowledgments = [
        "You're welcome! Feel free to reach out if there's more I can do for you.",
        "Glad to hear that! Don't hesitate to ask if you have more questions.",
        "Always here to help! What else can I assist you with today?",
        "That's great to know! If you need further information, just let me know.",
        "My pleasure! I'm here to help, so if you need anything else, just say the word.",
        "Anytime, that's what I'm here for! Do you have any other concerns?",
        "Of course! If there's more you're curious about, I'm here to help.",
        "I'm glad I could assist! Let me know if there's anything more you need.",
        "Sure thing! If you have any additional questions, I'm all ears.",
        "No problem at all! If you're looking for more assistance, I'm available.",
        "Cheers! If there's anything more to address, I'm here for you.",
        "You've got it! If anything else comes up, feel free to ask.",
        "Absolutely! Should you have any more queries, I'm here to answer them.",
        "Thank you for reaching out! If you have more to discuss, I'm ready when you are.",
        "I appreciate your interaction! If you have more questions, I'm ready to tackle them.",
        "That's what I'm here for! Let me know if there's anything else you'd like to explore.",
        "Glad to be of help! If you're curious about anything else, just shoot.",
        "Perfect! If there's more that you wish to inquire about, I'm here.",
        "Excellent! Should you need more assistance, don't hesitate to ask.",
        "Wonderful! I'm here to help, so if there's anything else, just let me know.",
    ]
    return random.choice(varied_acknowledgments)


def main(user_input, conversation_chain):
    if conversation_chain is None:
        raise Exception("The conversation chain is not initialized.")
    try:
        # Check if the user input is a simple acknowledgment
        if is_simple_acknowledgment(user_input):
            return generate_simple_response()
        response = conversation_chain({"question": user_input})
        return response["answer"]
    except Exception as e:
        print(f"Error during conversation chain processing: {e}")
        return "An error occurred while processing your request."
