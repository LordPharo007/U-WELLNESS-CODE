default_app_config = "chatbot.apps.ChatbotConfig"
