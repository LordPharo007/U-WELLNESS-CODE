from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from .gpt_lanchain import main

# from .initializer import conversation_chain, vectorstore
from .initializer import vectorstore
import json
from django.template import loader
from .models import Message
from .gpt_lanchain import get_conversation_chain


chat_history = {}


@csrf_exempt
@require_http_methods(
    ["POST", "GET"]
)  # This decorator ensures that only POST requests are accepted
def chatbot_view(request):
    # Ensure we're handling a POST request
    if request.method == "POST":
        try:
            # Parse the JSON body of the request
            data = json.loads(request.body)
            user_input = data.get("userinput")

            session_id = data.get("sessionId")

            print("session_id-", session_id)

            # Validate that user_input is provided
            if not user_input:
                return JsonResponse({"error": "No user input provided."}, status=400)

            if session_id in chat_history:
                conversation_chain = chat_history[session_id]
            else:
                conversation_chain = get_conversation_chain(vectorstore)

            # Get the response from the main function
            chatbot_response = main(user_input, conversation_chain)

            message = Message(user_msg=user_input, chatbot_msg=chatbot_response)
            message.save()

            chat_history[session_id] = conversation_chain

            return JsonResponse({"answer": chatbot_response})
        except json.JSONDecodeError:
            # If JSON decoding fails
            return JsonResponse({"error": "Invalid JSON."}, status=400)
        except KeyError:
            # If 'userinput' is not in JSON body
            return JsonResponse({"error": "Missing 'userinput' key."}, status=400)
    elif request.method == "GET":
        # Return the chatbot interface HTML template on GET request

        template = loader.get_template("chatbot_template.html")
        context = {"messages": []}

        return HttpResponse(template.render(context, request))
    else:
        # If it's not a POST request
        return JsonResponse({"error": "Only POST method is accepted."}, status=405)


def hello(request):
    # Ensure we're handling a POST request
    if request.method == "GET":
        return JsonResponse({"success": "Hello world"}, status=200)
