from django.db import models


# models to store data in the database.
class Message(models.Model):
    user_msg = models.TextField()
    chatbot_msg = models.TextField()
