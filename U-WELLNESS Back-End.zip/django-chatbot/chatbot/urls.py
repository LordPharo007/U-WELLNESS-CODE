from . import views
from django.urls import path


urlpatterns = [
    path("generate/", views.chatbot_view, name="chatbot-view"),
    path("", views.hello),
]
