# Setup

> Make sure the python version is 3.12
>
> Create Virtual Environment. 
>
> Install python dependencies using `pip install -r requirements.txt`
>
> Do migrations `python manage.py migrate`
>
> Update the .env 
>
> Run the server `python manage.py runserver`


## dataset

> To create dataset for finetuning. place the paragraph in dataset_generator.py file and run it. 